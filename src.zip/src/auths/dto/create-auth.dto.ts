export class CreateAuthDto {}
