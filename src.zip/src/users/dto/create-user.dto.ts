import { IsString, IsNotEmpty, IsNumber } from 'class-validator';


export class CreateUserDto {
    // @IsNotEmpty()
    // @IsString()
    // readonly first_name: string;

    // @IsNotEmpty()
    // @IsString()
    // readonly last_name: string;

    // @IsNotEmpty()
    // @IsString()
    // readonly email: string;

    // @IsNotEmpty()
    // @IsNumber()
    // readonly verify_code: number;
    
}
