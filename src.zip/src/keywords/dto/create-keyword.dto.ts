export class CreateKeywordDto {}
