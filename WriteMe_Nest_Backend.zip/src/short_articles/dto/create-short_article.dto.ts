export class CreateShortArticleDto {}
