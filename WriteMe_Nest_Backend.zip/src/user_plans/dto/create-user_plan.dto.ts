export class CreateUserPlanDto {}
