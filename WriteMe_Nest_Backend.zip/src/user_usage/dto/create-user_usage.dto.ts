export class CreateUserUsageDto {}
