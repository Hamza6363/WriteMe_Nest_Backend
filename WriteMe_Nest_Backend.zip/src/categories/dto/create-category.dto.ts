export class CreateCategoryDto {}
