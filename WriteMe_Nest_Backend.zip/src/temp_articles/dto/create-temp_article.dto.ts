export class CreateTempArticleDto {}
