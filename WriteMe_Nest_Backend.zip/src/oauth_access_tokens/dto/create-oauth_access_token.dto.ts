export class CreateOauthAccessTokenDto {}
